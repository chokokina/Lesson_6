# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '1671d937a35510996d5ca3cb98b58440538a5c2e50136a87e5660bdda03ec4055ff0f6ef6cc6b73dc438397b8ccfc2debd5d1852f5a6b17e675c7cdc717d2e59'
